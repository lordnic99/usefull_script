# Decompiled with PyLingual (https://pylingual.io)
# Internal filename: z.py
# Bytecode version: 3.10.0rc2 (3439)
# Source timestamp: 1970-01-01 00:00:00 UTC (0)

import subprocess
import re
import time
import sys
import os
if getattr(sys, 'frozen', False):
    base_dir = os.path.dirname(sys.executable)
else:
    base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, 'data', 'lc')
time_file_path = os.path.join(data_dir, 'SLPDPSD.txt')
hiy84b_file_path = os.path.join(data_dir, 'HIY84B.txt')
checklc_file_path = os.path.join(data_dir, 'checklc.txt')
name_file_path = os.path.join(data_dir, 'name.txt')

def tach_va_xu_ly_chuoi(input_string):
    try:
        parts = input_string.split('***')
        if len(parts) >= 4:
            last_part = parts[-1]
            os.makedirs(data_dir, exist_ok=True)
            with open(time_file_path, 'w') as time_file:
                time_file.write(last_part)
            remaining_string = '***'.join(parts[:-1])
            process_with_code_k(remaining_string)
        else:
            print('Key kích hoạt chưa chính xác.')
    except Exception as e:
        print(f'Đã xảy ra lỗi: {e}0')

def get_volume_serial_number():
    try:
        output = subprocess.check_output('wmic logicaldisk where "DeviceID=\'C:\'" get VolumeSerialNumber', shell=True)
        serial_number = re.search('([0-9A-Fa-f]{8})', output.decode()).group(1)
        return serial_number.strip()[-4:]
    except subprocess.CalledProcessError:
        print('Lỗi không xác định được thông tin máy.')
        return None

def process_with_code_k(input_string):
    os.makedirs(data_dir, exist_ok=True)
    with open(hiy84b_file_path, 'w') as file:
        file.write(input_string)
    process_file(hiy84b_file_path, checklc_file_path, name_file_path)
    clean_stars(checklc_file_path)

def process_file(input_path, checklc_path, name_path):
    try:
        with open(input_path, 'r') as file:
            content = file.read().strip()
        parts = content.split('***')
        if len(parts) >= 3:
            checklc_content = '***'.join(parts[:2])
            name_content = parts[-1]
            with open(checklc_path, 'w') as checklc_file:
                checklc_file.write(checklc_content)
            with open(name_path, 'w') as name_file:
                name_file.write(name_content)
        else:
            print('Nội dung file không đủ số phần mong muốn.')
    except Exception as e:
        print(f'Đã xảy ra lỗi: {e}0')

def clean_stars(file_path):
    try:
        with open(file_path, 'r') as file:
            content = file.read()
        cleaned_content = content.replace('***', '*')
        with open(file_path, 'w') as file:
            file.write(cleaned_content)
        print('Kích hoạt key thành công')
        time.sleep(5)
        run_code_a()
    except Exception as e:
        print(f'Đã xảy ra lỗi: {e}0')

def run_code_a():
    import os
    import sys
    if getattr(sys, 'frozen', False):
        base_dir = os.path.dirname(sys.executable)
    else:
        base_dir = os.path.dirname(os.path.abspath(__file__))
    directory = os.path.join(base_dir, 'data', 'lc')
    file_to_modify = 'TGDSD.txt'
    file_path = os.path.join(directory, file_to_modify)
    with open(file_path, 'w') as file:
        file.write('Z')
last_4_digits = get_volume_serial_number()
print(last_4_digits)
# if last_4_digits:
#     print('Mã Máy của bạn là:', last_4_digits, '\nHãy gửi mã này cho Admin FB PHAM VAN LONG SDT 0395633983 để lấy key kích hoạt!')
# chuoi_dau_vao = input('Nhập vào key kích hoạt: ')
# tach_va_xu_ly_chuoi(chuoi_dau_vao)