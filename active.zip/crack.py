# Decompiled with PyLingual (https://pylingual.io)
# Internal filename: ok.py
# Bytecode version: 3.10.0rc2 (3439)
# Source timestamp: 1970-01-01 00:00:00 UTC (0)

Bi = 'data/lc/TGDSD.txt'
Bh = Exception
AS = IOError
AR = FileNotFoundError
AQ = int
AP = 'Z'
k = chr
i = '0'
h = ord
U = 'frozen'
T = getattr
O = 'r'
import sys
K = sys.exit
H = False
G = ''
D = open
A = print
import os as B
import sys

def I(content):
    A = G
    for B in content:
        if B.isalpha():
            if B == AP:
                A += i
            else:  # inserted
                A += str(h(B) - 64)
    return AQ(A)

def J():
    Bq = 'ok.mp3'
    Bp = 'ok.srt'
    Bo = 'giongdoc:'
    Bn = 'a.json'
    Bm = 'Đang tạo voice ! thời gian có thể lâu .vui lòng chờ!!'
    Bg = '1.json'
    Bf = 'splitext'
    Be = '.mp3'
    Bc = '.txt'
    Ba = 'wb'
    BZ = 'rb'
    BY = 'text'
    BX = 'list.txt'
    BW = 'utf-8'
    BV = 'Đang bắt đầu xử lý!'
    BU = 'voicetts'
    BT = 'Có lỗi khi đọc file.'
    BS = 'File name.txt không tìm thấy.'
    BR = 'name.txt'
    BQ = 'Không tìm thấy kết quả cho ký tự đặc biệt đầu vào.'
    BP = '/'
    BO = '()*'
    BN = '}'
    BM = '{'
    BL = '$'
    BK = '!'
    BJ = 'Không tìm thấy kết quả cho ký tự đầu vào.'
    BI = 'FOL'
    BH = 'ENK'
    BG = 'DMJ'
    BF = 'CLI'
    BE = 'BKH'
    BD = 'AJG'
    BC = 'ZIF'
    BB = 'YHE'
    BA = 'XGD'
    B9 = 'WFC'
    B8 = 'VEB'
    B7 = 'UDA'
    B6 = 'TCZ'
    B5 = 'SBY'
    B4 = 'RAX'
    B3 = 'QZW'
    B2 = 'PYV'
    B1 = 'OXU'
    B0 = 'NWT'
    A_ = 'MVS'
    Az = 'LUR'
    Ay = 'KTQ'
    Ax = 'JSP'
    Aw = 'IRO'
    Av = 'HQN'
    Au = 'GMP'
    At = 'Y'
    As = 'X'
    Ar = 'W'
    Aq = 'V'
    Ap = 'U'
    Ao = 'T'
    An = 'S'
    Am = 'R'
    Al = 'Q'
    Ak = 'P'
    Aj = 'O'
    Ai = 'N'
    Ah = 'M'
    Ag = 'L'
    Af = 'K'
    Ae = 'J'
    Ad = 'I'
    Ac = 'H'
    Ab = 'G'
    Aa = 'F'
    AZ = 'E'
    AY = 'D'
    AX = 'C'
    AW = 'B'
    AV = 'A'
    AU = '([0-9A-Fa-f]{8})'
    AT = 'wmic logicaldisk where \"DeviceID=\'C:\'\" get VolumeSerialNumber'
    AO = '__main__'
    AN = 'voice'
    AM = 'Key sai rồi. Liên Hệ FB PHAM VAN LONG ,ZALO 0395633983'
    AJ = '%d/%m/%Y'
    AI = '!@#$%^&*()_+-=[]{}|;\':\",.<>?/'
    AH = 'DMJDMJDMJDMJ'
    AG = '?'
    AF = ','
    AE = '>'
    AD = '<'
    AC = '\''
    AB = '\"'
    AA = ';'
    A9 = '\\'
    A8 = '|'
    A7 = '['
    A6 = '='
    A5 = '-'
    A4 = '_'
    A3 = ')'
    A2 = '('
    A1 = '&'
    A0 = '^'
    z = '%'
    y = '#'
    x = '@'
    w = '9'
    v = '8'
    u = '7'
    t = '6'
    s = '5'
    r = '4'
    q = '3'
    p = '2'
    o = '1'
    n = 'checklc.txt'
    m = '.'
    j = ':'
    X = 'key bị sai, Liên Hệ FB PHAM VAN LONG ,ZALO 0395633983'
    W = 'Hethansudung, Liên Hệ FB PHAM VAN LONG ,ZALO 0395633983'
    V = ']'
    S = '+'
    R = None
    Q = True
    N = '*'
    P = 'lc'
    J = '147'
    I = '369'
    E = 'data'
    C = '258'
    import subprocess as Y
    import re
    import os as B
    import datetime as L
    import time as F
    import sys

    def M():
        if T(sys, U, H):
            return B.getcwd()
        return B.path.dirname(B.path.abspath(__file__))

    def AK():
        C = B.path.join(M(), E, P, n)
        if not B.path.isfile(C):
            A('Không tìm thấy file checklc.txt. Liên Hệ FB PHAM VAN LONG ,ZALO 0395633983')
            return
        with D(C, O) as F:
            G = F.readline().strip()
        H, I = G.split(N)
        return H

    def Z():
        C = B.path.join(M(), E, P, n)
        if not B.path.isfile(C):
            A(AM)
            return
        with D(C, O) as F:
            G = F.readline().strip()
        I, H = G.split(N)
        return H

    def a():
        try:
            A = Y.check_output(AT, shell=Q)
            B = re.search(AU, A.decode()).group(1)
            C = B.strip()[(-4):]
            return C
        except Y.CalledProcessError:
            return None

    def b(character):
        A = character
        B = {AV: Au, AW: Av, AX: Aw, AY: Ax, AZ: Ay, Aa: Az, Ab: A_, Ac: B0, Ad: B1, Ae: B2, Af: B3, Ag: B4, Ah: B5, Ai: B6, Aj: B7, Ak: B8, Al: B9, Am: BA, An: BB, Ao: BC, Ap: BD, Aq: BE, Ar: BF, As: BG, At: BH, AP: BI, i: C, o: I, p: J, q: C, r: I, s: J, t: C, u: I, v: J, w: w, B: A.upper(), A.upper(): name.txt, <mask_70>: ()*, }: {, $: !, A.upper(): Không tìm thấy kết quả cho ký tự đầu vào.}
        return B.get(A, BJ)

    def c(character):
        A = {BK: A2, x: y, y: x, BL: z, z: A0, A0: A1, A1: N, N: A3, A2: A4, A3: S, A4: BO, S: A5, A5: A6, A6: S, BM: A7, BN: V, A7: V, A8: A9, A9: j, j: AA, AA: AB, AB: AC, AC: AD, AD: AE, AE: AF, AF: m, m: AG, AG: BP, i: C, o: I, p: J, q: C, r: I, s: J, t: C, u: I, v: J, w: C}
        return A.get(character, BQ)

    def d(chuoi_ma_hoa):
        return G.join((k(h(A) - 3) for A in chuoi_ma_hoa))

    def e(today_date, decoded_date):
        if today_date < decoded_date:
            return Q
        A(W)
        F.sleep(10)
        K()

    def AL(chuoi_ma_hoa):
        return G.join((k(h(A) - 3) for A in chuoi_ma_hoa))

    def f():
        C = B.path.join(M(), E, P, BR)
        try:
            with D(C, O) as F:
                G = F.read().strip()
        except AR:
            A(BS)
            return H
        except AS:
            A(BT)
            return H
        I = AL(G)
        J = BU
        if J == I:
            return Q
        A(X)
        return H

    def g():
        nonlocal J  # inserted
        nonlocal sys  # inserted
        nonlocal B  # inserted
        import os as B
        import sys
        A(Bm)

        def J():
            if T(sys, U, H):
                return B.getcwd()
            return B.path.dirname(B.path.abspath(__file__))

        def C():
            K = J()
            D = B.path.join(K, E)
            for H, L, I in B.walk(D):
                for A in I:
                    C = B.path.join(H, A)
                    if A.endswith(Be) and C!= B.path.join(D, AN, BX):
                        B.remove(C)
            for H, L, I in B.walk(D):
                for A in I:
                    C = B.path.join(H, A)
                    if A.endswith('.srt') and C!= B.path.join(D, AN, BX):
                        B.remove(C)
            F = B.path.join(D, Bf)
            if B.path.exists(F) and B.path.isdir(F):
                for A in B.listdir(F):
                    C = B.path.join(F, A)
                    if A.endswith(Bc) and C!= B.path.join(D, AN, BX):
                        B.remove(C)
            G = B.path.join(D, BY)
            if not B.path.exists(G) or B.path.isdir(G):
                for A in B.listdir(G):
                    C = B.path.join(G, A)
                    if A.endswith(Bc) and C!= B.path.join(D, AN, BX):
                        B.remove(C)
        if __name__ == AO:
            C()

    def l():
        O = M()
        H = AK()
        if H == AH:
            A(G)
        else:  # inserted
            if H is R:
                return
            D = a()
            C = G
            if D:
                for B in D:
                    if B.isalpha() or B.isdigit():
                        C += b(B)
                    else:  # inserted
                        if B in AI:
                            C += c(B)
                        else:  # inserted
                            C += B
                if C == H:
                    A(BV)
            I = L.date.today()
            E = Z()
            if E is R:
                return
            J = d(E)
            N = L.datetime.strptime(J, AJ).date()
            if e(I, N):
                if f():
                    g()
                else:  # inserted
                    A(X)
                    F.sleep(5)
                    K()
            else:  # inserted
                A(W)
                F.sleep(10)
                K()
        if H == AH:
            D = a()
            C = G
            if D:
                for B in D:
                    if B.isalpha() or B.isdigit():
                        C += b(B)
                    else:  # inserted
                        if B in AI:
                            C += c(B)
                        else:  # inserted
                            C += B
            I = L.date.today()
            E = Z()
            if E is R:
                return
            J = d(E)
            N = L.datetime.strptime(J, AJ).date()
            if e(I, N):
                if f():
                    g()
                else:  # inserted
                    A(X)
                    F.sleep(5)
                    K()
            else:  # inserted
                A(W)
                F.sleep(10)
                K()
    if __name__ == AO:
        l()
    import subprocess as Y
    import re
    import os as B
    import datetime as L
    import time as F
    import sys

    def M():
        if T(sys, U, H):
            return B.getcwd()
        return B.path.dirname(B.path.abspath(__file__))

    def AK():
        C = B.path.join(M(), E, P, n)
        if not B.path.isfile(C):
            A('Key sai. Liên Hệ FB PHAM VAN LONG ,ZALO 0395633983')
            return
        with D(C, O) as F:
            G = F.readline().strip()
        H, I = G.split(N)
        return H

    def Z():
        C = B.path.join(M(), E, P, n)
        if not B.path.isfile(C):
            A(AM)
            return
        with D(C, O) as F:
            G = F.readline().strip()
        I, H = G.split(N)
        return H

    def a():
        try:
            A = Y.check_output(AT, shell=Q)
            B = re.search(AU, A.decode()).group(1)
            C = B.strip()[(-4):]
            return C
        except Y.CalledProcessError:
            return None

    def b(character):
        A = character
        B = {AV: Au, AW: Av, AX: Aw, AY: Ax, AZ: Ay, Aa: Az, Ab: A_, Ac: B0, Ad: B1, Ae: B2, Af: B3, Ag: B4, Ah: B5, Ai: B6, Aj: B7, Ak: B8, Al: B9, Am: BA, An: BB, Ao: BC, Ap: BD, Aq: BE, Ar: BF, As: BG, At: BH, AP: BI, i: C, o: I, p: J, q: C, r: I, s: J, t: C, u: I, v: J, w: w, B: A.upper(), A.upper(): name.txt, <mask_70>: ()*, }: {, $: !, A.upper(): Không tìm thấy kết quả cho ký tự đầu vào.}
        return B.get(A, BJ)

    def c(character):
        A = {BK: A2, x: y, y: x, BL: z, z: A0, A0: A1, A1: N, N: A3, A2: A4, A3: S, A4: BO, S: A5, A5: A6, A6: S, BM: A7, BN: V, A7: V, A8: A9, A9: j, j: AA, AA: AB, AB: AC, AC: AD, AD: AE, AE: AF, AF: m, m: AG, AG: BP, i: C, o: I, p: J, q: C, r: I, s: J, t: C, u: I, v: J, w: C}
        return A.get(character, BQ)

    def d(chuoi_ma_hoa):
        return G.join((k(h(A) - 3) for A in chuoi_ma_hoa))

    def e(today_date, decoded_date):
        if today_date < decoded_date:
            return Q
        A(W)
        F.sleep(10)
        K()

    def AL(chuoi_ma_hoa):
        return G.join((k(h(A) - 3) for A in chuoi_ma_hoa))

    def f():
        C = B.path.join(M(), E, P, BR)
        try:
            with D(C, O) as F:
                G = F.read().strip()
        except AR:
            A(BS)
            return H
        except AS:
            A(BT)
            return H
        I = AL(G)
        J = BU
        if J == I:
            return Q
        A(X)
        return H

    def g():
        nonlocal C  # inserted
        nonlocal B  # inserted
        import os as B
        import random as I
        import shutil as J
        import sys
        import time
        if T(sys, U, H):
            D = B.path.dirname(sys.executable)
        else:  # inserted
            D = B.path.dirname(B.path.abspath(__file__))
        C = B.path.join(D, BY)
        K = B.path.join(D, E, BY)
        if B.path.exists(C) and B.listdir(C):
            F = [A for A in B.listdir(C) if B.path.isfile(B.path.join(C, A))]
            if F:
                G = I.choice(F)
                L = B.path.join(C, G)
                M = B.path.join(K, G)
                J.move(L, M)
            else:  # inserted
                A('Thư mục không chứa file nào.')
        else:  # inserted
            A(f'Thư mục {C} không tồn tại hoặc rỗng.')
        if __name__ == AO:
            pass  # postinserted
        time.sleep(1)

    def l():
        O = M()
        H = AK()
        if H == AH:
            A(G)
        else:  # inserted
            if H is R:
                return
            D = a()
            C = G
            if D:
                for B in D:
                    if B.isalpha() or B.isdigit():
                        C += b(B)
                    else:  # inserted
                        if B in AI:
                            C += c(B)
                        else:  # inserted
                            C += B
                if C == H:
                    A(BV)
            I = L.date.today()
            E = Z()
            if E is R:
                return
            J = d(E)
            N = L.datetime.strptime(J, AJ).date()
            if e(I, N):
                if f():
                    g()
                else:  # inserted
                    A(X)
                    F.sleep(5)
                    K()
            else:  # inserted
                A(W)
                F.sleep(10)
                K()
        if H == AH:
            D = a()
            C = G
            if D:
                for B in D:
                    if B.isalpha() or B.isdigit():
                        C += b(B)
                    else:  # inserted
                        if B in AI:
                            C += c(B)
                        else:  # inserted
                            C += B
            I = L.date.today()
            E = Z()
            if E is R:
                return
            J = d(E)
            N = L.datetime.strptime(J, AJ).date()
            if e(I, N):
                if f():
                    g()
                else:  # inserted
                    A(X)
                    F.sleep(5)
                    K()
            else:  # inserted
                A(W)
                F.sleep(10)
                K()
    if __name__ == AO:
        l()
    import subprocess as Y
    import re
    import os as B
    import datetime as L
    import time as F
    import sys

    def M():
        if T(sys, U, H):
            return B.getcwd()
        return B.path.dirname(B.path.abspath(__file__))

    def AK():
        C = B.path.join(M(), E, P, n)
        if not B.path.isfile(C):
            A(AM)
            return
        with D(C, O) as F:
            G = F.readline().strip()
        H, I = G.split(N)
        return H

    def Z():
        C = B.path.join(M(), E, P, n)
        if not B.path.isfile(C):
            A(AM)
            return
        with D(C, O) as F:
            G = F.readline().strip()
        I, H = G.split(N)
        return H

    def a():
        try:
            A = Y.check_output(AT, shell=Q)
            B = re.search(AU, A.decode()).group(1)
            C = B.strip()[(-4):]
            return C
        except Y.CalledProcessError:
            return None

    def b(character):
        A = character
        B = {AV: Au, AW: Av, AX: Aw, AY: Ax, AZ: Ay, Aa: Az, Ab: A_, Ac: B0, Ad: B1, Ae: B2, Af: B3, Ag: B4, Ah: B5, Ai: B6, Aj: B7, Ak: B8, Al: B9, Am: BA, An: BB, Ao: BC, Ap: BD, Aq: BE, Ar: BF, As: BG, At: BH, AP: BI, i: C, o: I, p: J, q: C, r: I, s: J, t: C, u: I, v: J, w: w, B: A.upper(), A.upper(): name.txt, <mask_70>: ()*, }: {, $: !, A.upper(): Không tìm thấy kết quả cho ký tự đầu vào.}
        return B.get(A, BJ)

    def c(character):
        A = {BK: A2, x: y, y: x, BL: z, z: A0, A0: A1, A1: N, N: A3, A2: A4, A3: S, A4: BO, S: A5, A5: A6, A6: S, BM: A7, BN: V, A7: V, A8: A9, A9: j, j: AA, AA: AB, AB: AC, AC: AD, AD: AE, AE: AF, AF: m, m: AG, AG: BP, i: C, o: I, p: J, q: C, r: I, s: J, t: C, u: I, v: J, w: C}
        return A.get(character, BQ)

    def d(chuoi_ma_hoa):
        return G.join((k(h(A) - 3) for A in chuoi_ma_hoa))

    def e(today_date, decoded_date):
        if today_date < decoded_date:
            return Q
        A(W)
        F.sleep(10)
        K()

    def AL(chuoi_ma_hoa):
        return G.join((k(h(A) - 3) for A in chuoi_ma_hoa))

    def f():
        C = B.path.join(M(), E, P, BR)
        try:
            with D(C, O) as F:
                G = F.read().strip()
        except AR:
            A(BS)
            return H
        except AS:
            A(BT)
            return H
        I = AL(G)
        J = BU
        if J == I:
            return Q
        A(X)
        return H

    def g():
        L = ' '
        import os as B
        import random as R
        import re
        import sys
        import time
        if T(sys, U, H):
            J = B.path.dirname(sys.executable)
        else:  # inserted
            J = B.path.dirname(B.path.abspath(__file__))
        M = B.path.join(J, E, BY)
        N = B.path.join(J, E, Bf)
        B.makedirs(N, exist_ok=Q)
        P = [A for A in B.listdir(M) if A.endswith(Bc)]
        if P:
            S = R.choice(P)
            V = B.path.join(M, S)
            with D(V, O, encoding=BW) as W:
                K = W.read().replace('\n', L).replace('\r', G)
                K = re.sub('\\s+', L, K)
            F = re.split('(?<!\\w\\.\\w.)(?<![A-Z][a-z]\\.)(?<!\\d)(?<=\\w)(\\. |\\? |! |[。！？]+)', K)
            F = [A.strip() for A in F if A.strip()]
            I = []
            for C in range(0, len(F), 2):
                if C + 1 < len(F):
                    I.append(F[C] + F[C + 1])
                else:  # inserted
                    I.append(F[C])
            for C in range(0, len(I), 3):
                X = I[C:C + 3]
                Y = B.path.join(N, f'{C // 3 + 1}.txt')
                with D(Y, 'w', encoding=BW) as Z:
                    Z.write(L.join(X))
        else:  # inserted
            A('Không có file text nào trong thư mục.')
        time.sleep(3)

    def l():
        O = M()
        H = AK()
        if H == AH:
            A(G)
        else:  # inserted
            if H is R:
                return
            D = a()
            C = G
            if D:
                for B in D:
                    if B.isalpha() or B.isdigit():
                        C += b(B)
                    else:  # inserted
                        if B in AI:
                            C += c(B)
                        else:  # inserted
                            C += B
                if C == H:
                    A(BV)
            I = L.date.today()
            E = Z()
            if E is R:
                return
            J = d(E)
            N = L.datetime.strptime(J, AJ).date()
            if e(I, N):
                if f():
                    g()
                else:  # inserted
                    A(X)
                    F.sleep(5)
                    K()
            else:  # inserted
                A(W)
                F.sleep(10)
                K()
        if H == AH:
            D = a()
            C = G
            if D:
                for B in D:
                    if B.isalpha() or B.isdigit():
                        C += b(B)
                    else:  # inserted
                        if B in AI:
                            C += c(B)
                        else:  # inserted
                            C += B
            I = L.date.today()
            E = Z()
            if E is R:
                return
            J = d(E)
            N = L.datetime.strptime(J, AJ).date()
            if e(I, N):
                if f():
                    g()
                else:  # inserted
                    A(X)
                    F.sleep(5)
                    K()
            else:  # inserted
                A(W)
                F.sleep(10)
                K()
    if __name__ == AO:
        l()
        import os as B
        import pickle as Bj
        from cryptography.fernet import Fernet as Bk
        from google.auth.transport.requests import Request
        from google.oauth2.credentials import Credentials
        from google_auth_oauthlib.flow import InstalledAppFlow as Br
        from googleapiclient.discovery import build
        import json as Bd
        import requests as Bb
        import time as F
        from concurrent.futures import ThreadPoolExecutor as Bs
        import sys

        def Bl(encrypted_file_path, cipher, output_file_path):
            with D(encrypted_file_path, BZ) as A:
                B = A.read()
            C = cipher.decrypt(B)
            with D(output_file_path, Ba) as E:
                E.write(C)

        def Bt():
            with D('data/lc/secret.key', BZ) as B:
                C = B.read()
            A = Bk(C)
            E = 'data/lc/a.enc'
            F = 'data/lc/b.enc'
            Bl(E, A, 'data/lc/a.json')
            Bl(F, A, 'data/lc/b.pickle')

        def Bu(credentials_path):
            C = credentials_path
            A = R
            if B.path.exists(C):
                with D(C, BZ) as E:
                    A = Bj.load(E)
            if not A or not A.valid:
                if A and A.expired and A.refresh_token:
                    A.refresh(Request())
                else:  # inserted
                    F = Br.from_client_secrets_file(B.path.join(B.path.dirname(C), Bn), SCOPES)
                    A = F.run_local_server(port=0)
                with D(C, Ba) as E:
                    Bj.dump(A, E)
            return build('drive', 'v3', credentials=A)

        def Bv(setting_file):
            with D(setting_file, O) as B:
                A = B.readline().strip()
                if A.startswith(Bo):
                    return A.split(j)[1].strip()

        def Bw(file_path):
            with D(file_path, O) as A:
                return A.readline().strip()

        def Bx(service, folder_id, file_name):
            A = f'name=\'{file_name}\' and mimeType=\'text/plain\' and \'{folder_id}\' in parents'
            B = service.files().list(q=A, fields='files(id, name)').execute()
            C = B.get('files', [])
            return len(C) > 0

        def By():
            nonlocal C  # inserted
            nonlocal a  # inserted
            nonlocal L  # inserted
            nonlocal g  # inserted
            nonlocal J  # inserted
            nonlocal e  # inserted
            nonlocal d  # inserted
            nonlocal b  # inserted
            nonlocal c  # inserted
            nonlocal f  # inserted
            L = 'b.pickle'
            K = 'settingvoice.txt'
            I = m
            M = B.path.join(I, K)
            C = B.path.join(I, E, P)
            N = B.path.join(C, 'HIY84B.txt')
            S = Bv(M)
            if S is R:
                A('Không tìm thấy giá trị giongdoc trong file settingvoice.txt.')
                return
            V = Bw(N)
            W = B.path.join(I, E, P, L)
            X = Bu(W)
            Y = '1sIfehTC7t2SrKz--x6ANQfIpX0DadkO-'
            Z = Bx(X, Y, V)
            if Z:
                if T(sys, U, H):
                    I = B.path.dirname(sys.executable)
                else:  # inserted
                    I = B.path.dirname(B.path.abspath(__file__))
                C = B.path.join(I, E, P)

                def J(encrypted_file_path, cipher, output_file_path):
                    with D(encrypted_file_path, BZ) as A:
                        B = A.read()
                    C = cipher.decrypt(B)
                    with D(output_file_path, Ba) as E:
                        E.write(C)

                def a():
                    E = B.path.join(C, 'secret.key')
                    with D(E, BZ) as F:
                        G = F.read()
                    A = Bk(G)
                    H = B.path.join(C, 'a.enc')
                    I = B.path.join(C, 'b.enc')
                    J(H, A, B.path.join(C, Bn))
                    J(I, A, B.path.join(C, L))

                def b(text, shift):
                    B = G
                    for A in text:
                        if A.isalpha():
                            C = 65 if A.isupper() else 97
                            B += k((h(A) - C - shift) % 26 + C)
                        else:  # inserted
                            B += A
                    return B

                def c():
                    A = B.path.join(C, 'config.txt')
                    with D(A, O) as E:
                        F = E.read()
                    G = 3
                    H = b(F, G)
                    return H

                def d(input_file_path, output_file_path, shift):
                    def B(text, shift):
                        B = G
                        for A in text:
                            if A.isalpha():
                                C = 65 if A.isupper() else 97
                                B += k((h(A) - C - shift) % 26 + C)
                            else:  # inserted
                                B += A
                        return B
                    with D(input_file_path, O) as A:
                        C = A.read()
                    E = B(C, shift)
                    F = Bd.loads(E)
                    with D(output_file_path, 'w') as A:
                        Bd.dump(F, A, indent=4)

                def e(G):
                    A = B.path.dirname(sys.executable) if T(sys, U, H) else B.path.dirname(B.path.abspath(__file__))
                    C = B.path.join(A, E, P, f'{G}.json')
                    D = B.path.join(A, E, P, Bg)
                    F = 3
                    d(C, D, F)

                def f():
                    I = B.path.dirname(sys.executable) if T(sys, U, H) else B.path.dirname(B.path.abspath(__file__))
                    J = B.path.join(I, K)
                    L = {'English': 'en-US', 'Portuguese': 'pt-PT', 'German': 'de-DE', 'Korean': 'ko-KR', 'Japanese': 'ja-JP', 'French': 'fr-FR', 'Spanish': 'es-ES', 'Simplified Chinese': 'zh-CN', 'Traditional Chinese': 'zh-HK'}
                    with D(J, O, encoding=BW) as M:
                        N = M.readlines()
                        E = R
                        F = R
                        G = R
                        for C in N:
                            C = C.strip()
                            if C.startswith(Bo):
                                E = C.split(j)[1].strip()
                            else:  # inserted
                                if C.startswith('speed:'):
                                    F = C.split(j)[1].strip()
                                else:  # inserted
                                    if C.startswith('ngonngu:'):
                                        P = C.split(j)[1].strip()
                                        G = L.get(P, 'Unknown')
                    A(Bm)
                    return (E, F, G)

                def g(G, S, N, ZZZZZZZZ):
                    nonlocal K  # inserted
                    nonlocal J  # inserted
                    nonlocal C  # inserted
                    nonlocal V  # inserted
                    C = B.path.dirname(sys.executable) if T(sys, U, H) else B.path.dirname(B.path.abspath(__file__))
                    with D(B.path.join(C, E, P, Bg), O) as I:
                        R = Bd.load(I)
                    J = {A['name']: A['value'] for A in R}
                    K = B.path.join(C, E, Bf)
                    L = [A for A in B.listdir(K) if A.endswith(Bc)]
                    if not L:
                        raise AR('Không tìm thấy file .txt nào trong thư mục data/splitext.')
                    M = B.path.join(C, E, P, f'{G}.txt')
                    if not B.path.exists(M):
                        raise AR(f'Không tìm thấy file {G}.txt.')
                    with D(M, O, encoding=BW) as I:
                        V = I.read().strip()

                    def W(selected_file):
                        I = selected_file
                        H = 'list'
                        T = B.path.join(K, I)
                        with D(T, O, encoding=BW) as U:
                            W = U.read().strip()
                        L = ZZZZZZZZ
                        X = {'Accept': 'application/json, text/plain, */*', 'Content-Type': 'application/json'}
                        Y = {'task_contents': [{'sentence': W, 'task_index': 1, 'phonemes': []}], 'lang_code': N, 'break_times': [], 'speech_rate': AQ(S), 'pitch_rate': 0, 'volume': 5, 'voice_id': V, 'platform_id': 21}
                        M = Bb.post(L, headers=X, json=Y, cookies=J)
                        if M.status_code == 200:
                            Z = M.json()
                            a = Z[E]['task_id']
                            while Q:
                                b = f'{L}/{a}0'
                                P = Bb.get(b, cookies=J)
                                if P.status_code == 200:
                                    G = P.json()
                                    if G[E][H]:
                                        A('Đang tạo voice ! thời gian có thể lâu .vui lòng chờ!')
                                    else:  # inserted
                                        F.sleep(2)
                                else:  # inserted
                                    A('Có lỗi xảy ra khi lấy dữ liệu:')
                                    continue
                            c = G[E][H][0]['download_url']
                            d = G[E][H][0]['subtitle_url']
                            R = B.path.splitext(I)[0]
                            e = B.path.join(C, E, AN, f'{R}.mp3')
                            f = B.path.join(C, E, AN, f'{R}.srt')
                            g = Bb.get(c)
                            with D(e, Ba) as h:
                                h.write(g.content)
                            A('Đang tạo voice ! vui lòng chờ!')
                            i = Bb.get(d)
                            with D(f, Ba) as j:
                                j.write(i.content)
                        else:  # inserted
                            A('Có lỗi xảy ra cho file:')
                    with Bs(max_workers=2) as X:
                        X.map(W, L)

                def i():
                    a()
                    B = c()
                    A, C, D = f()
                    e(A)
                    g(A, C, D, B)
                    F.sleep(6)
                if __name__ == AO:
                    i()
            else:  # inserted
                A('Key bị sai liên hệ FB Pham Van Long Zalo 0395633983.')

        def l():
            Bt()
            By()
        if __name__ == AO:
            l()
    import subprocess as Y
    import re
    import os as B
    import datetime as L
    import time as F
    import sys

    def M():
        if T(sys, U, H):
            return B.getcwd()
        return B.path.dirname(B.path.abspath(__file__))

    def AK():
        C = B.path.join(M(), E, P, n)
        if not B.path.isfile(C):
            A(AM)
            return
        with D(C, O) as F:
            G = F.readline().strip()
        H, I = G.split(N)
        return H

    def Z():
        C = B.path.join(M(), E, P, n)
        if not B.path.isfile(C):
            A(AM)
            return
        with D(C, O) as F:
            G = F.readline().strip()
        I, H = G.split(N)
        return H

    def a():
        try:
            A = Y.check_output(AT, shell=Q)
            B = re.search(AU, A.decode()).group(1)
            C = B.strip()[(-4):]
            return C
        except Y.CalledProcessError:
            return None

    def b(character):
        A = character
        B = {AV: Au, AW: Av, AX: Aw, AY: Ax, AZ: Ay, Aa: Az, Ab: A_, Ac: B0, Ad: B1, Ae: B2, Af: B3, Ag: B4, Ah: B5, Ai: B6, Aj: B7, Ak: B8, Al: B9, Am: BA, An: BB, Ao: BC, Ap: BD, Aq: BE, Ar: BF, As: BG, At: BH, AP: BI, i: C, o: I, p: J, q: C, r: I, s: J, t: C, u: I, v: J, w: w, B: A.upper(), A.upper(): name.txt, <mask_70>: ()*, }: {, $: !, A.upper(): Không tìm thấy kết quả cho ký tự đầu vào.}
        return B.get(A, BJ)

    def c(character):
        A = {BK: A2, x: y, y: x, BL: z, z: A0, A0: A1, A1: N, N: A3, A2: A4, A3: S, A4: BO, S: A5, A5: A6, A6: S, BM: A7, BN: V, A7: V, A8: A9, A9: j, j: AA, AA: AB, AB: AC, AC: AD, AD: AE, AE: AF, AF: m, m: AG, AG: BP, i: C, o: I, p: J, q: C, r: I, s: J, t: C, u: I, v: J, w: C}
        return A.get(character, BQ)

    def d(chuoi_ma_hoa):
        return G.join((k(h(A) - 3) for A in chuoi_ma_hoa))

    def e(today_date, decoded_date):
        if today_date < decoded_date:
            return Q
        A(W)
        F.sleep(10)
        K()

    def AL(chuoi_ma_hoa):
        return G.join((k(h(A) - 3) for A in chuoi_ma_hoa))

    def f():
        C = B.path.join(M(), E, P, BR)
        try:
            with D(C, O) as F:
                G = F.read().strip()
        except AR:
            A(BS)
            return H
        except AS:
            A(BT)
            return H
        I = AL(G)
        J = BU
        if J == I:
            return Q
        A(X)
        return H

    def g():
        nonlocal C  # inserted
        nonlocal I  # inserted
        nonlocal B  # inserted
        import os as A
        from pydub import AudioSegment as G
        from datetime import timedelta as B
        import pysrt
        from concurrent.futures import ThreadPoolExecutor as D
        import sys
        C = A.path.join(A.path.dirname(sys.executable) if T(sys, U, H) else A.path.dirname(A.path.abspath(__file__)), E, AN)

        def I(duration_ms):
            A = duration_ms
            C = B(milliseconds=A)
            D, E = divmod(C.total_seconds(), 3600)
            F, G = divmod(E, 60)
            H = A % 1000
            return (D, F, G, H)

        def F(filename):
            E = filename
            H = A.path.join(C, E)
            D = A.path.join(C, E.replace(Be, '.srt'))
            if not A.path.exists(D):
                return
            J = G.from_mp3(H)
            K = len(J)
            F = pysrt.open(D)
            B = F[(-1)]
            L, M, N, O = I(K)
            B.end.hours = AQ(L)
            B.end.minutes = AQ(M)
            B.end.seconds = AQ(N)
            B.end.milliseconds = AQ(O)
            F.save(D, encoding=BW)
        with D() as J:
            K = [A for A in A.listdir(C) if A.endswith(Be)]
            J.map(F, K)

    def l():
        O = M()
        H = AK()
        if H == AH:
            A(G)
        else:  # inserted
            if H is R:
                return
            D = a()
            C = G
            if D:
                for B in D:
                    if B.isalpha() or B.isdigit():
                        C += b(B)
                    else:  # inserted
                        if B in AI:
                            C += c(B)
                        else:  # inserted
                            C += B
                if C == H:
                    A(BV)
            I = L.date.today()
            E = Z()
            if E is R:
                return
            J = d(E)
            N = L.datetime.strptime(J, AJ).date()
            if e(I, N):
                if f():
                    g()
                else:  # inserted
                    A(X)
                    F.sleep(5)
                    K()
            else:  # inserted
                A(W)
                F.sleep(10)
                K()
        if H == AH:
            D = a()
            C = G
            if D:
                for B in D:
                    if B.isalpha() or B.isdigit():
                        C += b(B)
                    else:  # inserted
                        if B in AI:
                            C += c(B)
                        else:  # inserted
                            C += B
            I = L.date.today()
            E = Z()
            if E is R:
                return
            J = d(E)
            N = L.datetime.strptime(J, AJ).date()
            if e(I, N):
                if f():
                    g()
                else:  # inserted
                    A(X)
                    F.sleep(5)
                    K()
            else:  # inserted
                A(W)
                F.sleep(10)
                K()
    if __name__ == AO:
        l()
    import subprocess as Y
    import re
    import os as B
    import datetime as L
    import time as F
    import sys

    def M():
        if T(sys, U, H):
            return B.getcwd()
        return B.path.dirname(B.path.abspath(__file__))

    def AK():
        C = B.path.join(M(), E, P, n)
        if not B.path.isfile(C):
            A(AM)
            return
        with D(C, O) as F:
            G = F.readline().strip()
        H, I = G.split(N)
        return H

    def Z():
        C = B.path.join(M(), E, P, n)
        if not B.path.isfile(C):
            A(AM)
            return
        with D(C, O) as F:
            G = F.readline().strip()
        I, H = G.split(N)
        return H

    def a():
        try:
            A = Y.check_output(AT, shell=Q)
            B = re.search(AU, A.decode()).group(1)
            C = B.strip()[(-4):]
            return C
        except Y.CalledProcessError:
            return None

    def b(character):
        A = character
        B = {AV: Au, AW: Av, AX: Aw, AY: Ax, AZ: Ay, Aa: Az, Ab: A_, Ac: B0, Ad: B1, Ae: B2, Af: B3, Ag: B4, Ah: B5, Ai: B6, Aj: B7, Ak: B8, Al: B9, Am: BA, An: BB, Ao: BC, Ap: BD, Aq: BE, Ar: BF, As: BG, At: BH, AP: BI, i: C, o: I, p: J, q: C, r: I, s: J, t: C, u: I, v: J, w: w, B: A.upper(), A.upper(): name.txt, <mask_70>: ()*, }: {, $: !, A.upper(): Không tìm thấy kết quả cho ký tự đầu vào.}
        return B.get(A, BJ)

    def c(character):
        A = {BK: A2, x: y, y: x, BL: z, z: A0, A0: A1, A1: N, N: A3, A2: A4, A3: S, A4: BO, S: A5, A5: A6, A6: S, BM: A7, BN: V, A7: V, A8: A9, A9: j, j: AA, AA: AB, AB: AC, AC: AD, AD: AE, AE: AF, AF: m, m: AG, AG: BP, i: C, o: I, p: J, q: C, r: I, s: J, t: C, u: I, v: J, w: C}
        return A.get(character, BQ)

    def d(chuoi_ma_hoa):
        return G.join((k(h(A) - 3) for A in chuoi_ma_hoa))

    def e(today_date, decoded_date):
        if today_date < decoded_date:
            return Q
        A(W)
        F.sleep(10)
        K()

    def AL(chuoi_ma_hoa):
        return G.join((k(h(A) - 3) for A in chuoi_ma_hoa))

    def f():
        C = B.path.join(M(), E, P, BR)
        try:
            with D(C, O) as F:
                G = F.read().strip()
        except AR:
            A(BS)
            return H
        except AS:
            A(BT)
            return H
        I = AL(G)
        J = BU
        if J == I:
            return Q
        A(X)
        return H

    def g():
        import pysrt as D
        import os as A
        import sys
        F = A.path.join(A.path.dirname(sys.executable) if T(sys, U, H) else A.path.dirname(A.path.abspath(__file__)), E, AN)
        B = A.path.join(F, 'temp.srt')
        G = 1
        while Q:
            I = A.path.join(F, f'{G}0.srt')
            if not A.path.isfile(I):
                continue
            if G == 1:
                N = D.open(I)
                N.save(B)
            else:  # inserted
                J = D.open(B)
                K = D.open(I)
                L = J[(-1)].end
                for C in K:
                    C.start += L
                    C.end += L
                M = J + K
                for O, C in enumerate(M):
                    C.index = O + 1
                M.save(B)
            G += 1
        P = A.path.join(F, Bp)
        A.rename(B, P)

    def l():
        O = M()
        H = AK()
        if H == AH:
            A(G)
        else:  # inserted
            if H is R:
                return
            D = a()
            C = G
            if D:
                for B in D:
                    if B.isalpha() or B.isdigit():
                        C += b(B)
                    else:  # inserted
                        if B in AI:
                            C += c(B)
                        else:  # inserted
                            C += B
                if C == H:
                    A(BV)
            I = L.date.today()
            E = Z()
            if E is R:
                return
            J = d(E)
            N = L.datetime.strptime(J, AJ).date()
            if e(I, N):
                if f():
                    g()
                else:  # inserted
                    A(X)
                    F.sleep(5)
                    K()
            else:  # inserted
                A(W)
                F.sleep(10)
                K()
        if H == AH:
            D = a()
            C = G
            if D:
                for B in D:
                    if B.isalpha() or B.isdigit():
                        C += b(B)
                    else:  # inserted
                        if B in AI:
                            C += c(B)
                        else:  # inserted
                            C += B
            I = L.date.today()
            E = Z()
            if E is R:
                return
            J = d(E)
            N = L.datetime.strptime(J, AJ).date()
            if e(I, N):
                if f():
                    g()
                else:  # inserted
                    A(X)
                    F.sleep(5)
                    K()
            else:  # inserted
                A(W)
                F.sleep(10)
                K()
    if __name__ == AO:
        l()
    import subprocess as Y
    import re
    import os as B
    import datetime as L
    import time as F
    import sys

    def M():
        if T(sys, U, H):
            return B.getcwd()
        return B.path.dirname(B.path.abspath(__file__))

    def AK():
        C = B.path.join(M(), E, P, n)
        if not B.path.isfile(C):
            A(AM)
            return
        with D(C, O) as F:
            G = F.readline().strip()
        H, I = G.split(N)
        return H

    def Z():
        C = B.path.join(M(), E, P, n)
        if not B.path.isfile(C):
            A(AM)
            return
        with D(C, O) as F:
            G = F.readline().strip()
        I, H = G.split(N)
        return H

    def a():
        try:
            A = Y.check_output(AT, shell=Q)
            B = re.search(AU, A.decode()).group(1)
            C = B.strip()[(-4):]
            return C
        except Y.CalledProcessError:
            return None

    def b(character):
        A = character
        B = {AV: Au, AW: Av, AX: Aw, AY: Ax, AZ: Ay, Aa: Az, Ab: A_, Ac: B0, Ad: B1, Ae: B2, Af: B3, Ag: B4, Ah: B5, Ai: B6, Aj: B7, Ak: B8, Al: B9, Am: BA, An: BB, Ao: BC, Ap: BD, Aq: BE, Ar: BF, As: BG, At: BH, AP: BI, i: C, o: I, p: J, q: C, r: I, s: J, t: C, u: I, v: J, w: w, B: A.upper(), A.upper(): name.txt, <mask_70>: ()*, }: {, $: !, A.upper(): Không tìm thấy kết quả cho ký tự đầu vào.}
        return B.get(A, BJ)

    def c(character):
        A = {BK: A2, x: y, y: x, BL: z, z: A0, A0: A1, A1: N, N: A3, A2: A4, A3: S, A4: BO, S: A5, A5: A6, A6: S, BM: A7, BN: V, A7: V, A8: A9, A9: j, j: AA, AA: AB, AB: AC, AC: AD, AD: AE, AE: AF, AF: m, m: AG, AG: BP, i: C, o: I, p: J, q: C, r: I, s: J, t: C, u: I, v: J, w: C}
        return A.get(character, BQ)

    def d(chuoi_ma_hoa):
        return G.join((k(h(A) - 3) for A in chuoi_ma_hoa))

    def e(today_date, decoded_date):
        if today_date < decoded_date:
            return Q
        A(W)
        F.sleep(10)
        K()

    def AL(chuoi_ma_hoa):
        return G.join((k(h(A) - 3) for A in chuoi_ma_hoa))

    def f():
        C = B.path.join(M(), E, P, BR)
        try:
            with D(C, O) as F:
                G = F.read().strip()
        except AR:
            A(BS)
            return H
        except AS:
            A(BT)
            return H
        I = AL(G)
        J = BU
        if J == I:
            return Q
        A(X)
        return H

    def g():
        nonlocal sys  # inserted
        nonlocal L  # inserted
        nonlocal B  # inserted
        nonlocal C  # inserted
        nonlocal M  # inserted
        nonlocal N  # inserted
        import subprocess as C
        import os as B
        import sys
        import time
        F = B.path.dirname(sys.executable) if T(sys, U, H) else B.path.dirname(B.path.abspath(__file__))
        I = B.path.join(F, E, AN, BX)
        J = B.path.join(F, E, AN, Bq)
        C.run(['ffmpeg', '-f', 'concat', '-safe', i, '-i', I, '-c', 'copy', J], stdout=C.DEVNULL, stderr=C.DEVNULL)
        A('Sắp hoàn thành,một vài giây nữa ,voice và phụ đề sẽ được xuất ra thư mục voice!')
        time.sleep(4)
        import subprocess as C
        import os as B
        import sys

        def K():
            if T(sys, U, H):
                return B.path.dirname(sys.executable)
            return B.path.dirname(B.path.abspath(__file__))

        def L(file_path):
            try:
                B = C.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', file_path], stdout=C.PIPE, stderr=C.PIPE, text=Q)
                D = float(B.stdout.strip())
                return AQ(D // 60)
            except Bh as E:
                A(f'Lỗi khi kiểm tra độ dài file: {E}0')
                return 0

        def M(letter_string):
            A = G
            for B in letter_string:
                if B.isalpha():
                    if B == AP:
                        A += i
                    else:  # inserted
                        C = h(B) - 64
                        A += str(C)
            return A

        def N(number_string):
            A = G
            for B in number_string:
                if B.isdigit():
                    if B == i:
                        A += AP
                    else:  # inserted
                        C = k(AQ(B) + 64)
                        A += C
            return A

        def P():
            H = K()
            F = B.path.join(H, 'data/voice/ok.mp3')
            if not B.path.exists(F):
                A(f'File {F} không tồn tại!')
                return
            J = L(F)
            C = B.path.join(H, Bi)
            if not B.path.exists(C):
                A(f'File {C} không tồn tại, tạo mới file.')
                with D(C, 'w') as E:
                    E.write(G)
            try:
                with D(C, O) as E:
                    P = E.read().strip()
                I = AQ(M(P))
            except Bh as Q:
                A(f'Không thể giải mã nội dung file: {Q}0')
                I = 0
            R = J + I
            S = N(str(R))
            with D(C, 'w') as E:
                E.write(S)
        if __name__ == AO:
            P()

    def l():
        O = M()
        H = AK()
        if H == AH:
            A(G)
        else:  # inserted
            if H is R:
                return
            D = a()
            C = G
            if D:
                for B in D:
                    if B.isalpha() or B.isdigit():
                        C += b(B)
                    else:  # inserted
                        if B in AI:
                            C += c(B)
                        else:  # inserted
                            C += B
                if C == H:
                    A(BV)
            I = L.date.today()
            E = Z()
            if E is R:
                return
            J = d(E)
            N = L.datetime.strptime(J, AJ).date()
            if e(I, N):
                if f():
                    g()
                else:  # inserted
                    A(X)
                    F.sleep(5)
                    K()
            else:  # inserted
                A(W)
                F.sleep(10)
                K()
        if H == AH:
            D = a()
            C = G
            if D:
                for B in D:
                    if B.isalpha() or B.isdigit():
                        C += b(B)
                    else:  # inserted
                        if B in AI:
                            C += c(B)
                        else:  # inserted
                            C += B
            I = L.date.today()
            E = Z()
            if E is R:
                return
            J = d(E)
            N = L.datetime.strptime(J, AJ).date()
            if e(I, N):
                if f():
                    g()
                else:  # inserted
                    A(X)
                    F.sleep(5)
                    K()
            else:  # inserted
                A(W)
                F.sleep(10)
                K()
    if __name__ == AO:
        l()
    import subprocess as Y
    import re
    import os as B
    import datetime as L
    import time as F
    import sys

    def M():
        if T(sys, U, H):
            return B.getcwd()
        return B.path.dirname(B.path.abspath(__file__))

    def AK():
        C = B.path.join(M(), E, P, n)
        if not B.path.isfile(C):
            A(AM)
            return
        with D(C, O) as F:
            G = F.readline().strip()
        H, I = G.split(N)
        return H

    def Z():
        C = B.path.join(M(), E, P, n)
        if not B.path.isfile(C):
            A(AM)
            return
        with D(C, O) as F:
            G = F.readline().strip()
        I, H = G.split(N)
        return H

    def a():
        try:
            A = Y.check_output(AT, shell=Q)
            B = re.search(AU, A.decode()).group(1)
            C = B.strip()[(-4):]
            return C
        except Y.CalledProcessError:
            return None

    def b(character):
        A = character
        B = {AV: Au, AW: Av, AX: Aw, AY: Ax, AZ: Ay, Aa: Az, Ab: A_, Ac: B0, Ad: B1, Ae: B2, Af: B3, Ag: B4, Ah: B5, Ai: B6, Aj: B7, Ak: B8, Al: B9, Am: BA, An: BB, Ao: BC, Ap: BD, Aq: BE, Ar: BF, As: BG, At: BH, AP: BI, i: C, o: I, p: J, q: C, r: I, s: J, t: C, u: I, v: J, w: w, B: A.upper(), A.upper(): name.txt, <mask_70>: ()*, }: {, $: !, A.upper(): Không tìm thấy kết quả cho ký tự đầu vào.}
        return B.get(A, BJ)

    def c(character):
        A = {BK: A2, x: y, y: x, BL: z, z: A0, A0: A1, A1: N, N: A3, A2: A4, A3: S, A4: BO, S: A5, A5: A6, A6: S, BM: A7, BN: V, A7: V, A8: A9, A9: j, j: AA, AA: AB, AB: AC, AC: AD, AD: AE, AE: AF, AF: m, m: AG, AG: BP, i: C, o: I, p: J, q: C, r: I, s: J, t: C, u: I, v: J, w: C}
        return A.get(character, BQ)

    def d(chuoi_ma_hoa):
        return G.join((k(h(A) - 3) for A in chuoi_ma_hoa))

    def e(today_date, decoded_date):
        if today_date < decoded_date:
            return Q
        A(W)
        F.sleep(10)
        K()

    def AL(chuoi_ma_hoa):
        return G.join((k(h(A) - 3) for A in chuoi_ma_hoa))

    def f():
        C = B.path.join(M(), E, P, BR)
        try:
            with D(C, O) as F:
                G = F.read().strip()
        except AR:
            A(BS)
            return H
        except AS:
            A(BT)
            return H
        I = AL(G)
        J = BU
        if J == I:
            return Q
        A(X)
        return H

    def g():
        nonlocal sys  # inserted
        nonlocal B  # inserted
        import os as B
        import random as N
        import shutil as G
        import sys
        C = B.path.dirname(sys.executable) if T(sys, U, H) else B.path.dirname(B.path.abspath(__file__))
        O = B.path.join(C, E, BY)
        I = B.path.join(C, E, AN)
        D = B.path.join(C, AN)
        B.makedirs(D, exist_ok=Q)
        R = N.choice(B.listdir(O))
        J = B.path.splitext(R)[0]
        K = B.path.join(I, Bp)
        L = B.path.join(I, Bq)
        S = B.path.join(D, f'{J}0.srt')
        V = B.path.join(D, f'{J}0.mp3')
        if B.path.exists(K):
            G.move(K, S)
        if B.path.exists(L):
            G.move(L, V)
        import os as B
        import sys
        C = B.path.dirname(sys.executable) if T(sys, U, H) else B.path.dirname(B.path.abspath(__file__))
        M = B.path.join(C, E, P, Bg)
        if B.path.exists(M):
            B.remove(M)
        import os as B
        import sys
        from playsound import playsound as W

        def X():
            if T(sys, U, H):
                return B.getcwd()
            return B.path.dirname(B.path.abspath(__file__))
        C = X()
        F = B.path.join(C, E, 'tone.wav')
        if B.path.exists(F):
            W(F)
        else:  # inserted
            A(f'File \'tone.mp3\' does not exist in {B.path.dirname(F)}')

    def l():
        O = M()
        H = AK()
        if H == AH:
            A(G)
        else:  # inserted
            if H is R:
                return
            D = a()
            C = G
            if D:
                for B in D:
                    if B.isalpha() or B.isdigit():
                        C += b(B)
                    else:  # inserted
                        if B in AI:
                            C += c(B)
                        else:  # inserted
                            C += B
                if C == H:
                    A(BV)
            I = L.date.today()
            E = Z()
            if E is R:
                return
            J = d(E)
            N = L.datetime.strptime(J, AJ).date()
            if e(I, N):
                if f():
                    g()
                else:  # inserted
                    A(X)
                    F.sleep(5)
                    K()
            else:  # inserted
                A(W)
                F.sleep(10)
                K()
        if H == AH:
            D = a()
            C = G
            if D:
                for B in D:
                    if B.isalpha() or B.isdigit():
                        C += b(B)
                    else:  # inserted
                        if B in AI:
                            C += c(B)
                        else:  # inserted
                            C += B
            I = L.date.today()
            E = Z()
            if E is R:
                return
            J = d(E)
            N = L.datetime.strptime(J, AJ).date()
            if e(I, N):
                if f():
                    g()
                else:  # inserted
                    A(X)
                    F.sleep(5)
                    K()
            else:  # inserted
                A(W)
                F.sleep(10)
                K()
    if __name__ == AO:
        l()

def C():
    if T(sys, U, H):
        C = B.path.dirname(sys.executable)
    else:  # inserted
        C = B.path.dirname(B.path.abspath(__file__))
    L = B.path.join(C, 'data/lc/SLPDPSD.txt')
    M = B.path.join(C, Bi)
    with D(L, O) as E:
        N = E.read().strip()
    F = I(N)
    with D(M, O) as E:
        P = E.read().strip()
    K = I(P)
    if F == 90000000000000000000000:
        A(G)
        J()
    else:  # inserted
        if K < F:
            Q = F - K
            A(f'Vẫn còn thời lượng: {Q} phút')
            J()
        else:  # inserted
            A('Đã hết thời lượng')
C()