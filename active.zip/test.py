
def decode(chuoi_ma_hoa):
    return ''.join((chr(ord(A) - 3) for A in chuoi_ma_hoa))

print(decode('5424525358'))

def b(text="kwwsv://yluer-dss-dsl.zrqghuvkduh.frp/dsl/y1/yrlfh/wwv", shift=3):
    B = ''
    for A in text:
        if A.isalpha():
            C = 65 if A.isupper() else 97
            B += chr((ord(A) - C - shift) % 26 + C)
        else:  # inserted
            B += A
    return B

import requests as Bb

import json as Bd

with open("1.json", 'r') as I:
    R = Bd.load(I)
J = {A['name']: A['value'] for A in R}
# J = r"IR_gbd=wondershare.com; uts_id=uts1735110236.419; cebs=1; usi_id=3aa7br_1735110237; _ce.clock_data=-3033%2C45.80.184.224%2C1%2Cffc3218438300d069a0fd5dfa5c6e851%2CEdge%2CTH; _gcl_au=1.1.699070547.1735110237; srcSite=virbo.wondershare.com; _gid=GA1.2.112888354.1735110239; sign_identity=38b68d32-8a6d-44e7-bab7-66fdd60d075c; user_identity=%7B%22avatar%22%3A%22https%3A%2F%2Flh3.googleusercontent.com%2Fa%2FACg8ocLfcQfOFRpYRZGbEADrCnf-nLNuizdUiXXW3CuOw7oYfZugKuKP%3Ds96-c%22%2C%22email%22%3A%22nguy%2A%40gmail.com%22%2C%22first_name%22%3A%22%22%2C%22id%22%3A%22364089959%22%2C%22last_name%22%3A%22%22%2C%22mobile%22%3A%22%22%2C%22nickname%22%3A%22Hoang+Nguyen%22%2C%22t%22%3A%221735110253%22%2C%22vc%22%3A%224337f882ce02375f1c0c6a9940c85f4e%22%7D; cus_wid=364089959; referrer=virbo.wondershare.com; LCUTS_UID_900133=900133; sensorsdata2015jssdkcross=%7B%22distinct_id%22%3A%22193fca129f64bb-0e3b22e7e8f6a88-4c657b58-3686400-193fca129f7183b%22%2C%22first_id%22%3A%22%22%2C%22props%22%3A%7B%22%24latest_traffic_source_type%22%3A%22url%E7%9A%84domain%E8%A7%A3%E6%9E%90%E5%A4%B1%E8%B4%A5%22%2C%22%24latest_search_keyword%22%3A%22url%E7%9A%84domain%E8%A7%A3%E6%9E%90%E5%A4%B1%E8%B4%A5%22%2C%22%24latest_referrer%22%3A%22url%E7%9A%84domain%E8%A7%A3%E6%9E%90%E5%A4%B1%E8%B4%A5%22%7D%2C%22identities%22%3A%22eyIkaWRlbnRpdHlfY29va2llX2lkIjoiMTkzZmNhMTI5ZjY0YmItMGUzYjIyZTdlOGY2YTg4LTRjNjU3YjU4LTM2ODY0MDAtMTkzZmNhMTI5ZjcxODNiIn0%3D%22%2C%22history_login_id%22%3A%7B%22name%22%3A%22%22%2C%22value%22%3A%22%22%7D%2C%22%24device_id%22%3A%22193fca129f64bb-0e3b22e7e8f6a88-4c657b58-3686400-193fca129f7183b%22%7D; w_bbweb_sign_identity=d2061e59-c254-4a79-a6e5-9004fd15a056; pdsId=M0pxWDhLdWNQUkFDcHhXbGRkMHRMVkE=; vecweb_identity=0e71a4b7-b7de-4e22-bf25-a249ce802a5d; IR_15586=1735124472968%7C0%7C1735124472968%7C%7C; _uetsid=68794170c28e11efbace2fb699193d6b; _uetvid=687956e0c28e11ef8ddbb73cc940256d; cebsp_=8; _ga_24WTSJBD5B=GS1.1.1735123499.2.1.1735124477.41.0.1568677994; _ga=GA1.2.578892132.1735110238..; _ce.s=v~15c5671177ded1b4102bb13755d18f2132dd65fc~lcw~1735124570062~vir~new~lva~1735110236560~vpv~0~v11.cs~379855~v11.s~487ee060-c2ad-11ef-a13a-d9bb4804e08d~v11.sla~1735124570073~gtrk.la~m53sdajn~lcw~1735124570074"
L = "https://virbo-app-api.wondershare.com/api/v1/tts"
X = {'Accept': 'application/json, text/plain, */*', 'Content-Type': 'application/json'}
Y = {'task_contents': [{'sentence': "私は日本語を勉強しています", 'task_index': 1, 'phonemes': []}], "lang_code":"ja-JP", 'break_times': [], 'speech_rate': 1, 'pitch_rate': 0, 'volume': 5, "voice_code":"ja-JP-ShioriNeural", 'platform_id': 0, "ver":1}
# M = Bb.post(L, headers=X, json=Y, cookies=J)
# print(M.text)

# download = "https://virbo-app-api.wondershare.com/api/v1/tts-v2/1718617721448038414"
# M = Bb.get(download, cookies=J)
# print(M.text)
download = Bb.get("https://mx-virbo-storage.wondershare.com/pcloud%2F364089959%2F3%2F202412%2F1%2Fae5c73bd-16af-4e34-872a-56f091699f18.mp3?Expires=1735731198\u0026OSSAccessKeyId=LTAI5t6NUSsGoS98bTvmM8iT\u0026Signature=bpQHXulKyfLvi6OnpD92EhJckbg%3D")
print(download.status_code)
with open("hoang.mp3", "wb") as f:
    f.write(download.content)